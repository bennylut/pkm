from typing import Callable

# builtin extensions: 
global run_task  # run_task(task_name, *args, **kwargs)
global project_info  # dictionary containing information about the executing project context


# your task execution code:
def run():
    ...
