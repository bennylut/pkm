from pathlib import Path

global ask

if Path("pyproject.toml").exists() or Path("pyproject-group.toml").exists():
    task_parts = ask("name", prompt="Task Name", positional_arg=0).replace('-','_').split(".")
    task_name = task_parts[-1]
    task_path = str(Path("tasks").joinpath(*task_parts[:-1]))
else:
    say("[red]task generation should be initiated in the root of your project or project group[/]")
