global confirm
zoo_name = ask("zoo_name", prompt="Zoo Name", positional_arg=0)
package_sharing_enabled = confirm("package_sharing", prompt="Enable Package Sharing")
