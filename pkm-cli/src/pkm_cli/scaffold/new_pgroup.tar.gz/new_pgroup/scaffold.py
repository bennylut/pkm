global ask
group_name=ask("group_name", positional_arg=0)
